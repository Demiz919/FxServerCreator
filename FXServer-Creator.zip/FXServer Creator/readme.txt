Hello there! Thank you for downloading this, and hope you find this useful!
This tool is mainly designed for those who do not know the manual installation.
Here's the original link for FXServer: https://wiki.fivem.net/wiki/Running_FXServer

Here are the things included that will be in "server.cfg", and how to use them:
Server Folder Name - The drive your server will be on and the name of the directory your server will be hosted in.

Server Port - The port your server will use (Ignore if you intend on making the server only for yourself or testing).

Allow ScriptHook - Whether you want to enable client-sided scripts or not (set to 1 by default)

RCON Password - The password you use when connecting remotely using e.g IceCon. NOTICE: Please use a good password and not a short one. You want a safe connection, right?
				
Server Name - The name that will show up in the serverlist in FiveM.

Max Clients - The maximum amount of players that are allowed to join your server (default: 32).

Server licensekey - The license-key your server uses, otherwise you won't be able to play on the server.
(find your key: https://keymaster.fivem.net/)

Create Server - Creates your server with the customized settings. It also creates your runserver.bat file (launch 'runserver.bat' file to launch the server)



Thank you, love you all!
// Remexy64 - (https://www.gta5-mods.com/users/Remexy_)