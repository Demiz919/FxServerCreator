resource_type 'map' { gameTypes = { fivem = true } }

map 'map.lua'
