client_script 'runcode_cl.lua'
server_script 'runcode_sv.lua'
server_script 'runcode_web.lua'

client_script 'runcode_shared.lua'
server_script 'runcode_shared.lua'

resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'