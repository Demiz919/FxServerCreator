client_script 'omg.lua'
server_script 'srv.lua'